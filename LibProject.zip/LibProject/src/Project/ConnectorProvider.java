/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Project;
import java.sql.*;
/**
 *
 * @author Lenovo
 */
public class ConnectorProvider {
    public static Connection getCon(){
        try{
            Class.forName("com.mysql.jbdc.Driver");
            Connection con = DriverManager.getConnection("jbdc:mysql://localhost:3306/lms","root","123456");
            return con;
        }
        catch(Exception e){
            System.out.println(e);
            return null;
        }
    }
}
